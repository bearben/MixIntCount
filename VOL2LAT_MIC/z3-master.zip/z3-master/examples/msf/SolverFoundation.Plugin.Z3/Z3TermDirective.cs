
/*++
Copyright (c) 2015 Microsoft Corporation

--*/

﻿using Microsoft.SolverFoundation.Services;
using System;

namespace Microsoft.SolverFoundation.Plugin.Z3
{
    public class Z3TermDirective : Z3BaseDirective
    {
    }
}
